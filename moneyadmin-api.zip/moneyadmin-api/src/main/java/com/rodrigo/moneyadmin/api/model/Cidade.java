package com.rodrigo.moneyadmin.api.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

//import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "cidade")
//@JsonIgnoreProperties({ "estado"}) 
//caso queira que não mostre uma propiedade na hora
//que a consulta for feita pelo Spring Data. Obs: Pode colocar mas parametros dentro do @JsonIgnoreProperties
//ex: @JsonIgnoreProperties({ "estado", "nome"}) 
public class Cidade {
	
	@Id
	private Long codigo;
	
	private String nome;

	@ManyToOne
	@JoinColumn(name = "codigo_estado")
	private Estado estado;	
	
	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

	public String getNome() {
		return nome;	
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	
	public Estado getEstado() {
		return estado;
	}

	public void setEstado(Estado estado) {
		this.estado = estado;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cidade other = (Cidade) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		return true;
	}	
		
}
