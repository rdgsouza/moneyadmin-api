package com.example.moneyadmin.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MoneyApiApplicationTests {

	@Test
	void contextLoads() {
	}
}
